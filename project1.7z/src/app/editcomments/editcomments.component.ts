import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editcomments',
  templateUrl: './editcomments.component.html',
  styleUrls: ['./editcomments.component.css']
})
export class EditcommentsComponent implements OnInit {
  

  constructor() { }

  ngOnInit() {
  }

}
