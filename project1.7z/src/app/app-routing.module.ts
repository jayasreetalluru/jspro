import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {WealthmanagementComponent} from './wealthmanagement/wealthmanagement.component';
import{ManageusersComponent} from './manageusers/manageusers.component';
const routes: Routes = [ 

{ path: 'manageusers', component: ManageusersComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
