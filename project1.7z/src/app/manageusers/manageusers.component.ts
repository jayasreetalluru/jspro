import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-manageusers',
  templateUrl: './manageusers.component.html',
  styleUrls: ['./manageusers.component.css']
})
export class ManageusersComponent implements OnInit {
  users: any = [{ Name: 'ABC', LoginID: '0002158935', Role: 'PIM Invest', Status: 'Active', Language: 'F', BranchCode: '311,310,410', AssignedCodes: 'C2X' },
  { Name: 'ABC', LoginID: '0002158935', Role: 'PIM Invest', Status: 'Active', Language: 'F', BranchCode: '311,310,410', AssignedCodes: 'C2X' },
  { Name: 'ABC', LoginID: '0002158935', Role: 'PIM Invest', Status: 'Active', Language: 'F', BranchCode: '311,310,410', AssignedCodes: 'C2X' },
  { Name: 'ABC', LoginID: '0002158935', Role: 'PIM Invest', Status: 'Active', Language: 'F', BranchCode: '311,310,410', AssignedCodes: 'C2X' },
  { Name: 'ABC', LoginID: '0002158935', Role: 'PIM Invest', Status: 'Active', Language: 'F', BranchCode: '311,310,410', AssignedCodes: 'C2X' },
  { Name: 'ABC', LoginID: '0002158935', Role: 'PIM Invest', Status: 'Active', Language: 'F', BranchCode: '311,310,410', AssignedCodes: 'C2X' },
  { Name: 'ABC', LoginID: '0002158935', Role: 'PIM Invest', Status: 'Active', Language: 'F', BranchCode: '311,310,410', AssignedCodes: 'C2X' },
  { Name: 'ABC', LoginID: '0002158935', Role: 'PIM Invest', Status: 'Active', Language: 'F', BranchCode: '311,310,410', AssignedCodes: 'C2X' },]

  constructor(private router: Router) { }

  ngOnInit() {
  }

}
