import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WealthmanagementComponent } from './wealthmanagement.component';

describe('WealthmanagementComponent', () => {
  let component: WealthmanagementComponent;
  let fixture: ComponentFixture<WealthmanagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WealthmanagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WealthmanagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
