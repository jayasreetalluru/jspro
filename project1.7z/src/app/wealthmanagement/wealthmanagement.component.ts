import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import {Router} from '@angular/router';
@Component({
  selector: 'app-wealthmanagement',
  templateUrl: './wealthmanagement.component.html',
  styleUrls: ['./wealthmanagement.component.css']
})
export class WealthmanagementComponent implements OnInit {
  reports : any = [ {id: 'MI164955', text: 'PIM IPS or Annual Review'},
  {id: 'MI164955', text: 'PIM IPS or Annual Review'},
  {id: 'MI164955', text: 'PIM IPS or Annual Review'},
  {id: 'MI164955', text: 'PIM IPS or Annual Review'},
  {id: 'MI164955', text: 'PIM IPS or Annual Review'},
  {id: 'MI164955', text: 'PIM IPS or Annual Review'},
  {id: 'MI164955', text: 'PIM IPS or Annual Review'},
  {id: 'MI164955', text: 'PIM IPS or Annual Review'},
  {id: 'MI164955', text: 'PIM IPS or Annual Review'},
  {id: 'MI164955', text: 'PIM IPS or Annual Review'},
  {id: 'MI164955', text: 'PIM IPS or Annual Review'},
  {id: 'MI164955', text: 'PIM IPS or Annual Review'},]

  constructor(private httpService: HttpClient,private router:Router) { }
    // ADD CHART OPTIONS. 
    pieChartOptions = {
      responsive: true
  }

  pieChartLabels =  ['High', 'Medium', 'Low'];

  // CHART COLOR.
  pieChartColor:any = [
      {
          backgroundColor: ['rgb(255,0,0)','rgba(255, 102, 0, 0.9)','rgb(192,192,192)']
      }
  ]

  pieChartData:any = [
      { 
          data: []
      }
  ];
 
  ngOnInit() {
  
  this.httpService.get('./assets/piechart.json', {responseType: 'json'}).subscribe(
    data => {
        this.pieChartData = data as any [];	 // FILL THE CHART ARRAY WITH DATA.
    },
    (err: HttpErrorResponse) => {
        console.log (err.message);
    }
);
}
  
onChartClick(event) {
console.log(event);
}

edit(){
    console.log("edit funct");
}


}

